<?php
// Nội dung tệp index.php
